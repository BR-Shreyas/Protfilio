var typed = new Typed(".text", {
    strings: ["front-end developer", "backend-developer", "web developer"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});